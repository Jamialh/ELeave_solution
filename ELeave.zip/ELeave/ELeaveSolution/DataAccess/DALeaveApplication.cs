﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using ELeaveSolution.Models;
using ELeaveSolution.Classes;

namespace ELeaveSolution.DataAccess
{
    public class DALeaveApplication
    {
        private const ParameterDirection output = ParameterDirection.Output;
        static string strConn = Properties.Settings.Default.ELeaveConnString;
        private string strErrorMessage = "";
        private DataTable dtResult = new DataTable();
        private DataSet dsResult = new DataSet();

        #region GET QUERIES

        public DataTable getEmployeeDetail(long EmployeeID)
        {            
            try
            {
                using (SqlConnection objConn = new SqlConnection(strConn))
                {
                    objConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "usp_get_Employee";
                        cmd.Parameters.Add("@EmployeeID", SqlDbType.BigInt).Value = EmployeeID;
                        cmd.Connection = objConn;
                        using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                        {
                            adp.Fill(dtResult);
                        }
                    }
                }

                ResultValidation(dtResult);
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return dtResult;
        }

        public DataTable getLeaveApplicationDetail(long LeaveApplicationID)
        {            
            try
            {
                using (SqlConnection objConn = new SqlConnection(strConn))
                {
                    objConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "usp_get_LeaveApplication";
                        cmd.Parameters.Add("@LeaveApplicationID", SqlDbType.BigInt).Value = LeaveApplicationID;
                        cmd.Connection = objConn;
                        using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                        {
                            adp.Fill(dtResult);
                        }
                    }                    
                }
                ResultValidation(dtResult);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return dtResult;
        }

        #endregion

        #region UPDATE QUERIES
        public void updateLeaveApplicationStatus(LeaveApplication objLeaveApplication)
        {
            try
            {
                using (SqlConnection objConn = new SqlConnection(strConn))
                {
                    objConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "usp_upd_status_LeaveApplication";
                        cmd.Parameters.Add("@LeaveApplicationID", SqlDbType.BigInt).Value = objLeaveApplication.LeaveApplicationID;
                        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 10).Value = objLeaveApplication.Status;
                        cmd.Parameters.Add("@ErrorMessage", SqlDbType.VarChar, -1).Direction = output;
                        cmd.Connection = objConn;
                        cmd.ExecuteNonQuery();

                        strErrorMessage = cmd.Parameters["@ErrorMessage"].Value.ToString();
                        if (strErrorMessage != "")
                            throw new Exception(strErrorMessage);
                    }
                }
                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            
        }
        #endregion

        #region INSERT QUERIES
        public void InsertLeaveApplication(ref LeaveApplication objLeaveApplication)
        {
            DateTime StartTime = Convert.ToDateTime(objLeaveApplication.StartTime);
            DateTime EndTime = Convert.ToDateTime(objLeaveApplication.EndTime);

            try
            {
                using (SqlConnection objConn = new SqlConnection(strConn))
                {
                    objConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "usp_insert_LeaveApplication";

                        cmd.Parameters.Add("@EmployeeID", SqlDbType.BigInt).Value = objLeaveApplication.EmployeeID;
                        cmd.Parameters.Add("@StartDate", SqlDbType.Date).Value = objLeaveApplication.StartDate;
                        cmd.Parameters.Add("@StartTime", SqlDbType.Time).Value = StartTime.ToString("hh:mm:ss");
                        cmd.Parameters.Add("@EndDate", SqlDbType.Date).Value = objLeaveApplication.EndDate;
                        cmd.Parameters.Add("@EndTime", SqlDbType.Time).Value = EndTime.ToString("hh:mm:ss");
                        cmd.Parameters.Add("@Justification", SqlDbType.VarChar, 100).Value = objLeaveApplication.Justification;
                        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 10).Value = objLeaveApplication.Status;

                        cmd.Parameters.Add("@LeaveApplicationID", SqlDbType.BigInt).Direction = output;     
                        cmd.Parameters.Add("@ErrorMessage", SqlDbType.VarChar, -1).Direction = output;
                        cmd.Connection = objConn;
                        cmd.ExecuteNonQuery();

                        strErrorMessage = cmd.Parameters["@ErrorMessage"].Value.ToString();
                        if (strErrorMessage != "")
                            throw new Exception(strErrorMessage);

                        objLeaveApplication.LeaveApplicationID = Convert.ToInt64(cmd.Parameters["@LeaveApplicationID"].Value);

                    }
                }

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        #endregion

        private void ResultValidation(DataTable dt)
        {
            if (dt == null || dt.Rows.Count == 0)
                throw new Exception("No record found");
            if (strErrorMessage != "")
                throw new Exception(strErrorMessage);
        }
    }
}