﻿using System.Web;
using System.Web.Optimization;

namespace ELeaveSolution
{
    public class BundleConfig
    {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            //bundles.Add(new ScriptBundle("~/bundles/standardscript").Include(
            //            "~/Scripts/page_js/standard.js"));

            bundles.Add(new StyleBundle("~/bundles/app-assets-js").Include(
                       "~/app-assets/js/vendors.min.js",
                       "~/app-assets/vendors/jquery-validation/jquery.validate.min.js",
                       "~/app-assets/js/plugins.js",
                       "~/app-assets/js/custom/custom-script.js",
                       "~/app-assets/js/scripts/customizer.js",
                       "~/app-assets/js/scripts/form-validation.js",
                       "~/app-assets/js/scripts/advance-ui-modals.js",
                       "~/app-assets/js/scripts/advance-ui-toasts.js"));

            bundles.Add(new StyleBundle("~/Content/app-assets-css").Include(
                        "~/app-assets/vendors/vendors.min.css",
                        "~/app-assets/css/themes/vertical-modern-menu-template/materialize.css",
                        "~/app-assets/css/themes/vertical-modern-menu-template/style.css",
                        "~/app-assets/css/custom/custom.css"));
        }
    }
}
