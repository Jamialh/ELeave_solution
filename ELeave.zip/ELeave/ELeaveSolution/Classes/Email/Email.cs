﻿using System;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;

namespace ELeaveSolution.Classes
{
    public class Email
    {
        static string smtpAddress = Properties.Settings.Default.smtpAddress;
        static int portNumber = Properties.Settings.Default.portNumber;
        static bool enableSSL = false;
        static string emailFromAddress = Properties.Settings.Default.emailFromAddress; //Sender Email Address                  
        static string password = Properties.Settings.Default.password; //Sender Password
        //static int maxRetrySendMail = Properties.Settings.Default.maxRetrySendMail;

        public string emailToAddress = ""; //Receiver Email Address  
        public string subject = "";
        public string body = "";

        public MailMessage mail = new MailMessage();
        public SmtpClient smtp = new SmtpClient();

        protected int cntRetry = 0;
        

        public void SendEmail(string ProcessName)
        {
            try
            {
                smtp = new SmtpClient(smtpAddress, portNumber);
                mail.From = new MailAddress(emailFromAddress);
                mail.To.Add(emailToAddress);
                mail.Subject = subject;
                mail.Body = body;
                mail.IsBodyHtml = true;

                smtp.Credentials = new System.Net.NetworkCredential(emailFromAddress, password, "");
                smtp.EnableSsl = enableSSL;

                smtp.Send(mail);
            }
            catch (SmtpFailedRecipientsException ex)
            {
                for (int i = 0; i < ex.InnerExceptions.Length; i++)
                {
                    SmtpStatusCode status = ex.InnerExceptions[i].StatusCode;
                    if (status == SmtpStatusCode.MailboxBusy ||
                        status == SmtpStatusCode.MailboxUnavailable)
                    {

                        throw new Exception(string.Format("{0} has been submitted successfully, however email failed to send out - Mailbox unavailable", ProcessName));                        
                        //System.Threading.Thread.Sleep(5000);
                        //smtp.Send(mail);
                    }
                    else
                    {
                        throw new Exception(string.Format("{0} has been submitted successfully however system has failed to deliver message to {1}", ProcessName, ex.InnerExceptions[i].FailedRecipient));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("{0} has been submitted successfully, however email failed to send out - {1}", ProcessName, ex.Message));
            }

        }
    }
}
