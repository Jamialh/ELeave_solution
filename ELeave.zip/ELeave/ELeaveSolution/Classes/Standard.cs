﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;

namespace ELeaveSolution.Classes
{
    public enum enumLeaveApplicationStatus
    {
        PENDING,
        APPROVED,
        REJECTED,
        CANCELLED
    }

    public static class Standard
    {      

        public static long DefaultEmployeeID = 2;

        internal static string ValidateDateRange(DateTime StartDate, DateTime StartTime, DateTime EndDate, DateTime EndTime)
        {
            DateTime StartDateTime = Convert.ToDateTime(StartDate.ToString("yyyy-MM-dd") + " " + StartTime.ToString("hh:mm:ss"));
            DateTime EndDateTime = Convert.ToDateTime(EndDate.ToString("yyyy-MM-dd") + " " + EndTime.ToString("hh:mm:ss"));

            if (StartDateTime > EndDateTime)
                return "Start date and time must not greater than End date and time";
            if (StartDateTime < DateTime.Now)
                return "Start date and time must not be lesser than todays date and time";

            return "";
        }

        internal static double ConvertDateTimeToTimestamp(DateTime value)
        {
            TimeSpan epoch = (value - new DateTime(1970, 1, 1, 0, 0, 0, 0).ToLocalTime());
            //return the total seconds (which is a UNIX timestamp)
            return (double)epoch.TotalSeconds;
        }

        private static readonly DateTime Epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);


        internal static long ConvertToTimestamp(DateTime value)
        {
            TimeSpan elapsedTime = value - Epoch;
            return (long)elapsedTime.TotalSeconds;
        }
    }

    
}