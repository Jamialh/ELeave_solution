﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using ELeaveSolution.Models;

namespace ELeaveSolution.ViewModels
{
    public class vmLeaveApproval
    {
        public string EmployeeName { get; set; }
        public string EmployeeEmail { get; set; }
        public LeaveApplication objLeaveApplication { get; set; }
        public EventStatus objEventStatus { get; set; }
    }
}