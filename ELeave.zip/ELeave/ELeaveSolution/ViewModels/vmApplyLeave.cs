﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ELeaveSolution.Models;

namespace ELeaveSolution.ViewModels
{
    public class vmApplyLeave
    {
        public Employee objEmployee { get; set; }
        public LeaveApplication objLeaveApplication { get; set; }
        public EventStatus objEventStatus { get; set; }
        public EventStatus objFormValidationtatus { get; set; }
    }
}