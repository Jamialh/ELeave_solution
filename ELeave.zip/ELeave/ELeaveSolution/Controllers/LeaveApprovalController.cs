﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.Linq;
using System.Text;

using ELeaveSolution.ViewModels;
using ELeaveSolution.Models;
using ELeaveSolution.DataAccess;
using ELeaveSolution.Classes;
using ELeaveSolution.DataBinding;


namespace ELeaveSolution.Controllers
{
    public class LeaveApprovalController : Controller
    {
        DALeaveApplication daLeaveApplication = new DALeaveApplication();
        DBLeaveApplication dbLeaveApplication = new DBLeaveApplication();

        public ActionResult Index(int ID)
        {
            vmLeaveApproval objvmLeaveApproval = InitialvmLeaveApproval();

            try
            {
                DataTable dtLeaveApplication = daLeaveApplication.getLeaveApplicationDetail(ID);

                objvmLeaveApproval.EmployeeName = dtLeaveApplication.Rows[0]["EmployeeName"].ToString() ;
                objvmLeaveApproval.EmployeeEmail = dtLeaveApplication.Rows[0]["Email"].ToString();
                objvmLeaveApproval.objLeaveApplication = dbLeaveApplication.bindingLeaveApplication(dtLeaveApplication);

                if (objvmLeaveApproval.objLeaveApplication.Status != ((enumLeaveApplicationStatus)0).ToString())
                {
                    throw new Exception(string.Format("No leave application record with status {0} is found.", (enumLeaveApplicationStatus)0).ToString());
                }
            }
            catch (Exception ex)
            {
                objvmLeaveApproval.objEventStatus = new EventStatus()
                {
                    Error = true,
                    Messages = ex.Message,
                    RedirectPage = "../../Home/Index"
                };
                return View("Index", objvmLeaveApproval);
            }
            TempData["objvmLeaveApproval"] = objvmLeaveApproval;

            return View("Index", objvmLeaveApproval);

        }

        public ActionResult Approval(int Status)
        {
            vmLeaveApproval objvmLeaveApproval = InitialvmLeaveApproval();
            try
            {
                objvmLeaveApproval = (vmLeaveApproval)TempData["objvmLeaveApproval"];
                LeaveApplication objLeaveApplication = objvmLeaveApproval.objLeaveApplication;

                enumLeaveApplicationStatus approvalStatus = (enumLeaveApplicationStatus)Status;
                objLeaveApplication.Status = approvalStatus.ToString();
                daLeaveApplication.updateLeaveApplicationStatus(objLeaveApplication);

                Email objEmail = new Email();
                WriteLeaveApprovalEmail(ref objEmail, objvmLeaveApproval);
                objEmail.SendEmail("Leave approval");

                objvmLeaveApproval.objEventStatus = new EventStatus()
                {
                    Success = true,
                    Messages = string.Format("Leave application status has been {0}.", objLeaveApplication.Status),
                    RedirectPage = "../Home/Index"
                };
            }
            catch (Exception ex)
            {
                objvmLeaveApproval.objEventStatus = new EventStatus()
                {
                    Error = true,
                    Messages = ex.Message,
                    RedirectPage = "../Home/Index"
                };
            }
            return View("Index", objvmLeaveApproval);
        }

        private void WriteLeaveApprovalEmail(ref Email objEmail, vmLeaveApproval objvmLeaveApproval)
        {
            StringBuilder EmailBody = new StringBuilder();
            EmailBody.AppendLine(string.Format("Your leave application has been {0}", objvmLeaveApproval.objLeaveApplication.Status));
            EmailBody.AppendLine("<br/>");
            EmailBody.AppendLine("<br/>");

            EmailBody.AppendLine(string.Format("Employee Name: {0} <br/>", objvmLeaveApproval.EmployeeName));
            EmailBody.AppendLine(string.Format("Start date and time: {0} {1} <br/>", Convert.ToDateTime(objvmLeaveApproval.objLeaveApplication.StartDate).ToString("dd MMM yyyy"), Convert.ToDateTime(objvmLeaveApproval.objLeaveApplication.StartTime).ToString("hh:mm tt")));
            EmailBody.AppendLine(string.Format("End date and time: {0} {1} <br/>", Convert.ToDateTime(objvmLeaveApproval.objLeaveApplication.EndDate).ToString("dd MMM yyyy"), Convert.ToDateTime(objvmLeaveApproval.objLeaveApplication.EndTime).ToString("hh:mm tt")));


            objEmail.emailToAddress = objvmLeaveApproval.EmployeeEmail;
            objEmail.subject = string.Format("LEAVE Application has been {0}", objvmLeaveApproval.objLeaveApplication.Status);
            objEmail.body = EmailBody.ToString();
        }

        private vmLeaveApproval InitialvmLeaveApproval()
        {
            vmLeaveApproval objvmLeaveApproval = new vmLeaveApproval()
            {                
                objLeaveApplication = new LeaveApplication(),
                objEventStatus = new EventStatus()
            };

            return objvmLeaveApproval;
        }
    }
}