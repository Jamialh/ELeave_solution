﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Text;

using ELeaveSolution.ViewModels;
using ELeaveSolution.Models;
using ELeaveSolution.DataAccess;
using ELeaveSolution.Classes;
using ELeaveSolution.DataBinding;

namespace ELeaveSolution.Controllers
{
    public class ApplyLeaveController : Controller
    {
        DALeaveApplication daLeaveApplication = new DALeaveApplication();
        DBLeaveApplication dbLeaveApplication = new DBLeaveApplication();

        public ActionResult Index()
        {
            vmApplyLeave objvmApplyLeave = InitialvmApplyLeave();

            try
            {
                DataTable dtEmployee = daLeaveApplication.getEmployeeDetail(Standard.DefaultEmployeeID);

                objvmApplyLeave.objEmployee = dbLeaveApplication.bindingEmployee(dtEmployee);
            }
            catch (Exception e)
            {
                objvmApplyLeave.objEventStatus = new EventStatus() { Error = true, Messages = e.Message };
                return View("Index", objvmApplyLeave);
            }

            return View("Index", objvmApplyLeave);
        }

        public ActionResult SubmitLeave(vmApplyLeave objvmApplyLeave)
        {
            try
            {
                string ValidationErrorMessage = Standard.ValidateDateRange(Convert.ToDateTime(objvmApplyLeave.objLeaveApplication.StartDate),
                    Convert.ToDateTime(objvmApplyLeave.objLeaveApplication.StartTime),
                    Convert.ToDateTime(objvmApplyLeave.objLeaveApplication.EndDate),
                    Convert.ToDateTime(objvmApplyLeave.objLeaveApplication.EndTime));

                if (ValidationErrorMessage != "")
                {
                    objvmApplyLeave.objFormValidationtatus = new EventStatus()
                    {
                        Error = true,
                        Messages = ValidationErrorMessage
                    };

                    objvmApplyLeave.objEventStatus = new EventStatus();
                }
                else 
                {
                    objvmApplyLeave.objFormValidationtatus = new EventStatus();
                    enumLeaveApplicationStatus statusPending = enumLeaveApplicationStatus.PENDING;

                    LeaveApplication objLeaveApplication = objvmApplyLeave.objLeaveApplication;
                    objLeaveApplication.EmployeeID = objvmApplyLeave.objEmployee.EmployeeID;
                    objLeaveApplication.Status = statusPending.ToString();
                    daLeaveApplication.InsertLeaveApplication(ref objLeaveApplication);

                    Email objEmail = new Email();
                    WriteApplyLeaveEmail(ref objEmail, objvmApplyLeave);
                    objEmail.SendEmail("Leave application");

                    objvmApplyLeave.objEventStatus = new EventStatus()
                    {
                        Success = true,
                        Messages = "Leave application has been submitted.",
                        RedirectPage = "../ApplyLeave/Index"
                    };
                }                
            }
            catch (Exception e)
            {
                objvmApplyLeave.objEventStatus = new EventStatus() { Error = true, Messages = e.Message };                
            }

            return View("Index", objvmApplyLeave);
        }

        private void WriteApplyLeaveEmail(ref Email objEmail, vmApplyLeave vmApplyLeave)
        {            
            StringBuilder EmailBody = new StringBuilder();

            EmailBody.AppendLine(string.Format("Employee Name: {0} <br/>", vmApplyLeave.objEmployee.EmployeeName));
            EmailBody.AppendLine(string.Format("Start date and time: {0} {1} <br/>", Convert.ToDateTime(vmApplyLeave.objLeaveApplication.StartDate).ToString("dd MMM yyyy"), Convert.ToDateTime(vmApplyLeave.objLeaveApplication.StartTime).ToString("hh:mm tt")));
            EmailBody.AppendLine(string.Format("End date and time: {0} {1} <br/>", Convert.ToDateTime(vmApplyLeave.objLeaveApplication.EndDate).ToString("dd MMM yyyy"), Convert.ToDateTime(vmApplyLeave.objLeaveApplication.EndTime).ToString("hh:mm tt")));
            
            EmailBody.AppendLine("<br/>");
            EmailBody.AppendLine("<br/>");
            EmailBody.AppendLine(string.Format("<a href = '{0}/LeaveApproval/Index/{1}' >Click here to view and confirm the leave application. </a>", Request.Url.Host, vmApplyLeave.objLeaveApplication.LeaveApplicationID));

            objEmail.emailToAddress = vmApplyLeave.objEmployee.Manager.Email;
            objEmail.subject = string.Format("LEAVE Application by {0}", vmApplyLeave.objEmployee.EmployeeName);
            objEmail.body = EmailBody.ToString();

        }

        private vmApplyLeave InitialvmApplyLeave()
        {
            vmApplyLeave objvmApplyLeave = new vmApplyLeave()
            {
                objEmployee = new Employee(),
                objLeaveApplication = new LeaveApplication(),
                objEventStatus = new EventStatus()
            };

            return objvmApplyLeave;
        }

        
    }
}