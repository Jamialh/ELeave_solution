﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using ELeaveSolution.Models;
using ELeaveSolution.ViewModels;


namespace ELeaveSolution.DataBinding
{
    public class DBLeaveApplication
    {
        public LeaveApplication bindingLeaveApplication(DataTable dtLeaveApplication)
        {
            LeaveApplication objLeaveApplication = new LeaveApplication();

            try
            {
                objLeaveApplication.EmployeeID = Convert.ToInt64(dtLeaveApplication.Rows[0]["EmployeeID"]);
                objLeaveApplication.LeaveApplicationID = Convert.ToInt64(dtLeaveApplication.Rows[0]["LeaveApplicationID"]);
                objLeaveApplication.StartDate = Convert.ToDateTime(dtLeaveApplication.Rows[0]["StartDate"]);
                objLeaveApplication.StartTime = Convert.ToDateTime(dtLeaveApplication.Rows[0]["StartTime"].ToString());
                objLeaveApplication.EndDate = Convert.ToDateTime(dtLeaveApplication.Rows[0]["EndDate"]);
                objLeaveApplication.EndTime = Convert.ToDateTime(dtLeaveApplication.Rows[0]["EndTime"].ToString());
                objLeaveApplication.ApplicationDateTime = Convert.ToDateTime(dtLeaveApplication.Rows[0]["ApplicationDateTime"]);

                objLeaveApplication.Justification = dtLeaveApplication.Rows[0]["Justification"].ToString();
                objLeaveApplication.Status = dtLeaveApplication.Rows[0]["Status"].ToString();
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return objLeaveApplication;
        }

        public Employee bindingEmployee(DataTable dtEmployee)
        {
            Employee objEmployee = new Employee();

            try
            {
                objEmployee.EmployeeID = Convert.ToInt64(dtEmployee.Rows[0]["EmployeeID"]);
                objEmployee.EmployeeName = dtEmployee.Rows[0]["EmployeeName"].ToString();
                objEmployee.Email = dtEmployee.Rows[0]["Email"].ToString();
                objEmployee.Manager = new Employee()
                {
                    EmployeeID = Convert.ToInt64(dtEmployee.Rows[0]["ManagerID"]),
                    EmployeeName = dtEmployee.Rows[0]["ManagerName"].ToString(),
                    Email = dtEmployee.Rows[0]["ManagerEmail"].ToString()
                };
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return objEmployee;
        }
    }
}