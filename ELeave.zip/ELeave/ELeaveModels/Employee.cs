﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ELeaveSolution.Models
{
    public class Employee
    {
        [Required(ErrorMessage = "Employee name must be specified")]
        public string EmployeeName { get; set; }
        public long EmployeeID { get; set; }
        public string Email { get; set; }       
        public string ManagerID { get; set; }
        public Employee Manager { get; set; }

    }
}