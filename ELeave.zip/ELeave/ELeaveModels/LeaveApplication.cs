﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ELeaveSolution.Models
{
    public class LeaveApplication
    {
        public DateTime ApplicationDateTime { get; set; }

        public long EmployeeID { get; set; }
        public long LeaveApplicationID { get; set; }

        [Required(ErrorMessage = "Start date must be specified")]
        public DateTime? StartDate { get; set; }

        [Required(ErrorMessage = "Start time must be specified")]
        public DateTime? StartTime { get; set; }

        [Required(ErrorMessage = "End Date must be specified")]
        public DateTime? EndDate { get; set; }

        [Required(ErrorMessage = "End time must be specified")]
        public DateTime? EndTime { get; set; }

        [Required(ErrorMessage = "Justification must be specified")]
        public string Justification { get; set; }

        public string Status { get; set; }
    }
}