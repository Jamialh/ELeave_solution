﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ELeaveSolution.Models
{
    public class EventStatus
    {
        public bool Success { get; set; }
        public bool Error { get; set; }
        public string Messages { get; set; }
        public string RedirectPage { get; set; }
    }
}